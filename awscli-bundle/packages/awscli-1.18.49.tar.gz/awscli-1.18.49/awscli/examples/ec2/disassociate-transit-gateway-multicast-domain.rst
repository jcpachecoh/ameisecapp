**To disassociate subnets from a multicast domain**

This example disassociates a subnet from the specified multicast domain. ::

    aws ec2 disassociate-transit-gateway-multicast-domain \
        --transit-gateway-attachment-id tgw-attach-070e571cd1EXAMPLE \
        --subnet-id subnet-000de86e3bEXAMPLE \
        --transit-gateway-multicast-domain-id tgw-mcast-domain-0c4905cef7EXAMPLE

Output::

    {
        "Associations": {
            "TransitGatewayMulticastDomainId": "tgw-mcast-domain-0c4905cef7EXAMPLE",
            "TransitGatewayAttachmentId": "tgw-attach-070e571cd1EXAMPLE",
            "ResourceId": "vpc-7EXAMPLE",
            "ResourceType": "vpc",
            "Subnets": [
                {
                    "SubnetId": "subnet-000de86e3bEXAMPLE",
                    "State": "disassociating"
                }
            ]
        }
    }

For more information, see 'Disassociate Subnets from a Transit Gateway Multicast Domain<https://docs.aws.amazon.com/vpc/latest/tgw/working-with-multicast.html#remove-subnet-association>'__ in the *AWS Transit Gateways User Guide*'.
